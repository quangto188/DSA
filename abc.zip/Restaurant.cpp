#include "main.h"

class imp_res : public Restaurant
{	public:
		int counter;
		customer *first;
		customer *X;
	public:	
		imp_res() {
			counter=0;
		};
		customer *find_RES(customer *cus){
			int RES = abs(first->energy - cus->energy);
			customer *a=first;
			customer *result = a;
			while (a!= first){
				if (abs(a->energy-cus->energy) > RES){
					RES = abs(a->energy-cus->energy);
					result = a;
				}
				a=a->next;
			}
			return result;
		}
		void RED(string name, int energy)
		{
			cout << name << " " << energy << endl;
			customer *cus = new customer (name, energy, nullptr, nullptr);
			if (first->energy ==  0){
				return;
			}
			if (counter ==0){ 
				first = cus;
				X= cus;
				counter++;
			}else if (counter < MAXSIZE/2){
				if (cus->energy >= X->energy){
					X->next=cus;
					X=X->next;
					counter++;
				}else{
					X->prev =cus;
					X= X->prev;
					counter++;
				}
			}else{
				X= find_RES(cus); //tim X
				int RES= X->energy-cus->energy;
				if (RES >=0){
					X->next =cus;
					X=X->next;
				}else{
					X->prev=cus;
					X=X->prev;
				}
			}


			

			
		}
		void BLUE(int num)
		{
			cout << "blue "<< num << endl;
		}
		void PURPLE()
		{
			cout << "purple"<< endl;
		}
		void REVERSAL()
		{
			cout << "reversal" << endl;
		}
		void UNLIMITED_VOID()
		{
			cout << "unlimited_void" << endl;
		}
		void DOMAIN_EXPANSION()
		{
			cout << "domain_expansion" << endl;
		}
		void LIGHT(int num)
		{
			cout << "light " << num << endl;
		}
};